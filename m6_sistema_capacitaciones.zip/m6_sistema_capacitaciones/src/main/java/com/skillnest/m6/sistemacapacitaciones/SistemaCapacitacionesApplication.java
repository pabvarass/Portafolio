package com.skillnest.m6.sistemacapacitaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCapacitacionesApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemaCapacitacionesApplication.class, args);
    }
}
