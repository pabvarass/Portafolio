package com.skillnest.m6.sistemacapacitaciones.repository;

import com.skillnest.m6.sistemacapacitaciones.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepository extends JpaRepository<Curso, Long> {
}
