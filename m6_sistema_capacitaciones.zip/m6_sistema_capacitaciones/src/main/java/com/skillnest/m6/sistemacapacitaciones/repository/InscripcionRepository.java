package com.skillnest.m6.sistemacapacitaciones.repository;

import com.skillnest.m6.sistemacapacitaciones.model.Inscripcion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InscripcionRepository extends JpaRepository<Inscripcion, Long> {
}
